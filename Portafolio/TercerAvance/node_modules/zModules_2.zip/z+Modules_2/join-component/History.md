
1.1.0 / 2012-12-29 
==================

  * add Oxford comma support
