1) What version of the module is the issue happening on? Does the issue happen on latest version?

2) What platform and Node.js version? (For example Node.js 0.12 on Mac OS X)

3) Sample source code or steps to reproduce

(Write description of your issue here, stack traces from errors and code that reproduces the issue are helpful)
