# Lighthouse logger

A shared logging utility class for lighthouse and friends.

