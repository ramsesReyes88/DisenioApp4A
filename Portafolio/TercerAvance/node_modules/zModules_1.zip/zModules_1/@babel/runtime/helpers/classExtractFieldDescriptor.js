var classPrivateFieldGet2 = require("./classPrivateFieldGet2.js");
function _classExtractFieldDescriptor(receiver, privateMap) {
  return classPrivateFieldGet2(privateMap, receiver);
}
module.exports = _classExtractFieldDescriptor, module.exports.__esModule = true, module.exports["default"] = module.exports;