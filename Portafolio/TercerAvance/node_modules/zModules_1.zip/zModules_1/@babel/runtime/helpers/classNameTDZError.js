function _classNameTDZError(name) {
  throw new ReferenceError("Class \"" + name + "\" cannot be referenced in computed property keys.");
}
module.exports = _classNameTDZError, module.exports.__esModule = true, module.exports["default"] = module.exports;